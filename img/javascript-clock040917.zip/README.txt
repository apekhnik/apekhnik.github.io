A Pen created at CodePen.io. You can find this one at https://codepen.io/beumsk/pen/YQoBJK.

 Clock displaying current time.
Created with HTML, CSS and pure JS.